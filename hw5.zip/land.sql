create database land;
use land;
create table information (
	name		        char(32)  	character set utf8,
	chil_1	    int(3),
    chil_2          int(3),
    chil_3          int(3),
    chil_4          int(3),
    adu_1	    int(3),
    adu_2          int(3),
    adu_3          int(3),
    adu_4          int(3)
);
describe information;